License
-------

.. literalinclude:: ../LICENSE
